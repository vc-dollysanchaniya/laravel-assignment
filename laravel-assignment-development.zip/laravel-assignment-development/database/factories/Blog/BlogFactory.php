<?php

namespace Database\Factories\Blog;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Constant\Constant;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Blog\Blog>
 */
class BlogFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {

        $title = $this->faker->realText(50);
        return [
            'blog_title' => $title,
            'description' => Str::random(10),
            'user_id' => rand(2, 6),
            'status' => Constant::STATUS_ONE,
        ];
    }
}
