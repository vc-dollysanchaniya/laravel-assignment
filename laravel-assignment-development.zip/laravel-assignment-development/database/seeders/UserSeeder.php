<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        try {
            $users = [
                [
                    'first_name' => "admin fname",
                    'last_name' => "admin lname",
                    'email' => 'admin@gmail.com',
                    'role_id' => '1',
                    'dob' =>  '1998-9-18',
                    'password' => Hash::make('Test@123##'),
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
                [
                    'first_name' => "vidhi",
                    'last_name' => "patel",
                    'email' => 'vidhi@gmail.com',
                    'role_id' => '2',
                    'dob' =>  '1998-9-19',
                    'password' => Hash::make('Test@123##'),
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
                [
                    'first_name' => "khushi",
                    'last_name' => "patel",
                    'email' => 'khushi@gmail.com',
                    'role_id' => '2',
                    'dob' =>  '1998-9-20',
                    'password' => Hash::make('Test@123##'),
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
                [
                    'first_name' => "kavin",
                    'last_name' => "patel",
                    'email' => 'kavin@gmail.com',
                    'role_id' => '2',
                    'dob' =>  '1998-9-21',
                    'password' => Hash::make('Test@123##'),
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
                [
                    'first_name' => "smita",
                    'last_name' => "patel",
                    'email' => 'smita@gmail.com',
                    'role_id' => '2',
                    'dob' =>  '1998-9-22',
                    'password' => Hash::make('Test@123##'),
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
                [
                    'first_name' => "rajesh",
                    'last_name' => "patel",
                    'email' => 'rajesh@gmail.com',
                    'role_id' => '2',
                    'dob' =>  '1998-9-23',
                    'password' => Hash::make('Test@123##'),
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
            ];
            foreach ($users as $user) {
                config('model-variables.models.user.class')::updateOrCreate([
                    'first_name' => $user['first_name'],
                    'last_name' => $user['last_name'],
                    'email' => $user['email'],
                    'role_id' => $user['role_id'],
                    'dob' => $user['dob'],
                    'password' => $user['password'],
                    'created_at' => $user['created_at'],
                    'updated_at' => $user['updated_at']
                ]);
            }
        } catch (Exception $ex) {
            Log::error($ex);
        }
    }
}
