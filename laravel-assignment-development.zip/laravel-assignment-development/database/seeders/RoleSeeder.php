<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Constant\Constant;
use Exception;
use Illuminate\Support\Facades\Log;

class RoleSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        try {
            $roles = [
                [
                    'name' => Constant::ADMIN,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ],
                [
                    'name' => Constant::USER,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
                ],
            ];
            foreach ($roles as $role) {
                config('model-variables.models.role.class')::updateOrCreate([
                    'name' => $role['name'],
                    'created_at' => $role['created_at'],
                    'updated_at' => $role['updated_at']
                ]);
            }
        } catch (Exception $ex) {
            Log::error($ex);
        }
    }
}
