<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use Exception;
use Illuminate\Support\Facades\Log;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        try {
            // disable foreign key constraints
            Schema::disableForeignKeyConstraints();

            // truncate all table before seeding
            config('model-variables.models.role.class')::truncate();
            config('model-variables.models.user.class')::truncate();
            config('model-variables.models.blog.class')::truncate();

            // enable foreign key constraints
            Schema::enableForeignKeyConstraints();

            //call all seeder to seed the data in database
            $this->call([
                RoleSeeder::class,
                UserSeeder::class,
                BlogSeeder::class,
            ]);
        } catch (Exception $ex) {
            Log::error($ex);
        }
    }
}
