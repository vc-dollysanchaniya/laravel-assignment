<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Frontend\Blog\BlogController;


Route::resource('blogs', BlogController::class)->middleware('role:2');;
