<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Backend\Dashboard\DashboardController;

//Route::group(['middleware' => ['auth', 'verified']], function () {
Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('role:1');
//});
