<?php

/**
 * Model-variables file contain all constant variables declaration of models which will be globally accessible.
 * Key of the table should be based on the table name (singular/plural)
 * Key of the Model class should be based on the class name (Always singular)
 */


use App\Models\User;
use App\Models\Role\Role;
use App\Models\Blog\Blog;

//use App\Models\Setting\Setting;

return [
    'models' => [
        /*
        * User table and model
        */
        'user' => [
            'table' => 'users',
            'class' => User::class,
        ],

        /*
        * Role table and model
        */
        'role' => [
            'table' => 'roles',
            'class' => Role::class,
        ],

        /*
        * Role table and model
        */
        'blog' => [
            'table' => 'blogs',
            'class' => Blog::class,
        ],

        /*
        * Setting table and model
        */
        // 'setting' => [
        //     'table' => 'settings',
        //     'class' => Setting::class,
        // ],

        /*
        * Passwordreset table
        */
        'passwordreset' => [
            'table' => 'password_resets'
        ],

        /*
        * Failedjob table
        */
        'failedjob' => [
            'table' => 'failed_jobs'
        ],

        /*
        * Personalaccesstoken table
        */
        'personalaccesstoken' => [
            'table' => 'personal_access_tokens'
        ],

    ],
];
