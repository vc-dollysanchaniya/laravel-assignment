<?php

/**
 * Config-variables file contain all config variables declaration - which will be globally accessible.
 */

return [

    'screenId' => [
        'screenOne'   => '1',
        'screenTwo'   => '2',
        'screenThree' => '3',
        'screenFour'  => '4',
        'screenFive'  => '5',
        'screenSix'   => '6'
    ],

    'diyaId' => [
        'diyaOne'   => '1',
        'diyaTwo'   => '2',
        'diyaThree' => '3',
        'diyaFour'  => '4'
    ],

    'lightenStatus' => [
        'isLighten'   => '1',
        'isNotLighten'   => '0',
    ],

    'flagStatus' => [
        'panding'   => '0',
        'continue' => '1',
        'close' => '2',
    ],

    'layoutRow' => [
        'rowZero'  => '0',
        'rowOne'   => '1',
        'rowTwo'   => '2',
        'rowThree' => '3',
        'rowFour'  => '4',
        'rowFive'  => '5',
        'rowSix'  =>  '6',
    ],

    'layoutColumn' => [
        'columnZero'  => '0',
        'columnOne'   => '1',
        'columnTwo'   => '2',
        'columnThree' => '3',
        'columnFour'  => '4',
        'columnFive'  => '5',
        //'columnSix'   => '6',
        //'columnSeven' => '7',
        //'columnEight' => '8'
    ],
];
