<?php

return [
    /* messages of create blog page */
    'page' => [
        'title' => 'Blogs',
    ],
    'create' => 'Create Blog',
    'notFound' => 'No blog found.',
    'table' => [
        'th' => [
            'title' => 'Title',
            'edit' => 'Edit',
            'delete' => 'Delete',
        ],
        'td' => [
            'title' => 'Enter Title',
            'description' => 'Enter Description',
        ],
        'submit' => 'Submit',
    ],
];
