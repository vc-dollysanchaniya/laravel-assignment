<?php

return [
    /* messages of create blog page */
    'page' => [
        'title' => 'Blogs',
    ],

    'form' => [
        'label' => [
            'title' => 'Title',
            'description' => 'Description',
        ],
        'placeholder' => [
            'title' => 'Enter Title',
            'description' => 'Enter Description',
        ],
        'submit' => 'Submit',
    ],
];
