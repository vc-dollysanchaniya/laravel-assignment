<?php

return [
    /* messages of create reister page */
    'page' => [
        'title' => 'Register',
    ],

    'form' => [
        'label' => [
            'firstName' => 'First Name',
            'lastName' => 'Last Name',
            'dob' => 'Date of Birth',
            'email' => 'Email Address',
            'password' => 'Password',
            'confirmPassword' => 'Confirm Password',
        ],
        'placeholder' => [
            'firstName' => 'Enter First Name',
            'lastName' => 'Enter Last Name',
        ],
        'register' => 'Register',
    ],
];
