<?php

return [
    /* messages of create verify page */
    'page' => [
        'title' => 'Verify Your Email Address',
    ],
    'linkSentMsg' => 'A fresh verification link has been sent to your email address.',
    'verifyMsg' => 'Before proceeding, please check your email for a verification link.',
    'notReceiveMsg' => 'If you did not receive the email',
    'resend' => 'click here to request another',
];
