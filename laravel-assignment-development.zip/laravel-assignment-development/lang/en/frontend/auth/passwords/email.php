<?php

return [
    /* messages of create reset password page */
    'page' => [
        'title' => 'Reset Password',
    ],

    'form' => [
        'label' => [
            'email' => 'Email Address',
        ],
        'sendRestLink' => 'Send Password Reset Link'
    ],

];
