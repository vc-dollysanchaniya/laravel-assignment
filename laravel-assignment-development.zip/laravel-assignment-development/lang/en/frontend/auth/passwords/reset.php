<?php

return [
    /* messages of create login page */
    'page' => [
        'title' => 'Reset Password',
    ],

    'form' => [
        'label' => [
            'email' => 'Email Address',
            'password' => 'Password',
            'confirmPassword' => 'Confirm Password',
        ],
        'resetPassword' => 'Reset Password',
    ],
];
