<?php

return [
    /* messages of create login page */
    'page' => [
        'title' => 'Confirm Password',
    ],
    'confirmPasswordMsg' => 'Please confirm your password before continuing.',
    'form' => [
        'label' => [
            'password' => 'Password',
            'confirmPassword' => 'Confirm Password',
        ],
    ],
    'forgotPassword' => 'Forgot Your Password?'
];
