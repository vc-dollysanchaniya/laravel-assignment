<?php

return [
    /* messages of create login page */
    'page' => [
        'title' => 'Login',
    ],

    'form' => [
        'label' => [
            'email' => 'Email Address',
            'password' => 'Password',
            'rememberMe' => 'Remember Me',
        ],
        'placeholder' => [
            'email' => 'Enter Email',
            'password' => 'Enter Password',
        ],
        'login' => 'Login',
    ],
    'forgotPassword' => 'Forgot Your Password?'
];
