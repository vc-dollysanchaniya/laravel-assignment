<?php

use function Ramsey\Uuid\v1;

return [
    /* messages of create blog page */
    'page' => [
        'title' => 'Welcome',
    ],
    'homeLink' => 'Home',
    'loginLink' => 'Login',
    'registerLink' => 'Register',
];
