<?php

return [
    /* messages of create blog page */
    'page' => [
        'title' => 'Home',
    ],
    'loggedInMsg' => 'You are logged in!',
];
