@extends('layouts.app')
@section('title', __('frontend/blog/list.page.title'))
@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">{{ __('frontend/blog/list.page.title') }}
					<a class="nav-link" href="{{ route('blogs.create') }}" style="float:right;"><button class="btn btn-primary">{{ __('frontend/blog/list.create') }}</button></a>
				</div>

				<div class="card-body">
					@if(count($blogs) > 0)
					<table class="table table-borderless" id="blogTable">

						<thead>
							<tr>
								<th>{{ __('frontend/blog/list.table.th.title') }}</th>
								<th>{{ __('frontend/blog/list.table.th.edit') }}</th>
								<th>{{ __('frontend/blog/list.table.th.delete') }}</th>
							</tr>
						</thead>
						<tbody>
							@foreach($blogs as $blog)
							<tr>
								<td>{{ $blog->blog_title }}
								</td>
								<td><a href="{{ route('blogs.edit',$blog->id) }}">{{ __('frontend/blog/list.table.th.edit') }}</a></td>
								<td>
									<form method="post" action="{{ route('blogs.destroy',$blog->id) }}">
										@csrf
										{{ method_field('DELETE') }}
										<button class="btn btn-primary">{{ __('frontend/blog/list.table.th.delete') }}</button>
									</form>
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
					@else
					<div>
						<h4>{{ __('frontend/blog/list.notFound') }}</h4>
					</div>
					@endif

				</div>
			</div>
		</div>
	</div>
</div>
@endsection
@section('script')
<script type="text/javascript">
	$(document).ready(function() {
		$('#blogTable').DataTable({
			//order: [[0, 'desc']],
		});
	});
</script>
@endsection