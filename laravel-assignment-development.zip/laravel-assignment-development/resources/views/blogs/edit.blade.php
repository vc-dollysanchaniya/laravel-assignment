@extends('layouts.app')
@section('title', __('frontend/blog/edit.page.title'))
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('frontend/blog/edit.page.title') }}</div>
                <div class="card-body">
                    <form action="{{ route('blogs.update', $blog->id) }}" method="POST" id="userBlog">
                        @csrf
                        {{ method_field('PUT') }}
                        <div class="form-group">
                            <label for="blogTitle">{{ __('frontend/blog/edit.form.label.title') }}</label>
                            <input type="text" name="blogTitle" class="form-control" id="blogTitle" placeholder="{{ __('frontend/blog/edit.form.placeholder.title') }}" value="{{ $blog->blog_title }}">
                        </div>
                        <div class="form-group">
                            <label for="description">{{ __('frontend/blog/edit.form.label.description') }}</label>
                            <input type="text" name="description" class="form-control" id="description" placeholder="{{ __('frontend/blog/edit.form.placeholder.description') }}" value="{{ $blog->description }}">
                        </div>
                        <button type="submit" class="btn btn-primary mt-2">{{ __('frontend/blog/edit.form.submit') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script type="text/javascript">
    if ($("#userBlog").length > 0) {
        $("#userBlog").validate({
            rules: {
                blogTitle: {
                    required: true,
                    maxlength: 20
                },
                description: {
                    required: true,
                    maxlength: 30,
                    minlength: 10
                },
            },
            messages: {
                blogTitle: {
                    required: "Please enter Title",
                    maxlength: "maximum length is 20 characters."
                },
                description: {
                    required: "Please enter Description",
                    maxlength: "maximum length is 30 characters.",
                    minlength: "minimum length is 10 characters."
                },
            },
        })
    }
</script>
@endpush