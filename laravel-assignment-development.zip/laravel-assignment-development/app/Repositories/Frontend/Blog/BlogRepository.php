<?php

namespace App\Repositories\Frontend\Blog;


use App\Helpers\Core\Helper;
use App\Repositories\Core\Repository;
use App\Constant\Constant;
use Illuminate\Support\Facades\Auth;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class BlogRepository extends Repository
{
	/**
	 * @var string
	 * Return the model
	 */
	public function __construct()
	{
		$this->model = config('model-variables.models.blog.class');
	}

	/**
	 * Get users records with pagination
	 * @return mixed
	 */
	public function index(): mixed
	{
		$response = "";
		try {
			$user = Auth::user();
			$response = $this->model::with('users')->where('user_id', $user->id)->orderBy('id', 'desc')->get();
		} catch (Exception $exception) {
			Log::error($exception);
		}
		return $response;
	}



	/**
	 * create a blog
	 * 
	 * @param  array  $request
	 * @return mixed
	 */
	public function store(array $request): mixed
	{
		$response = "";
		try {
			$user = Auth::user();
			DB::beginTransaction();
			$response = $this->model::create([
				'blog_title' => $request['blogTitle'],
				'description' => $request['description'],
				'user_id' => $user->id,
				'status' => Constant::STATUS_ONE,
			]);
			DB::commit();
		} catch (Exception $exception) {
			DB::rollBack();
			Log::error($exception);
		}
		return $response;
	}

	/**
	 * Update blog data
	 * 
	 * @param  array  $request
	 * @param  int  $id
	 * @return mixed
	 */
	public function update(int $id, array $request): mixed
	{
		$response = "";
		try {
			$user = Auth::user();
			DB::beginTransaction();
			$response = $this->model::where('id', $id)
				->update([
					'blog_title' => $request['blogTitle'],
					'description' => $request['description'],
					'user_id' => $user->id
				]);
			DB::commit();
		} catch (Exception $exception) {
			DB::rollBack();
			Log::error($exception);
		}
		return $response;
	}

	/**
	 * delete blog data
	 * 
	 * @param int $id
	 * @return mixed
	 */
	public function delete(int $id): mixed
	{
		$response = "";
		try {
			$response = $this->model::where('id', $id)->delete();
		} catch (Exception $exception) {
			DB::rollBack();
			Log::error($exception);
		}
		return $response;
	}
}
