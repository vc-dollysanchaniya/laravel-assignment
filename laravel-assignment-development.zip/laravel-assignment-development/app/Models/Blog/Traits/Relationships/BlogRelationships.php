<?php

namespace App\Models\Blog\Traits\Relationships;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Trait BlogRelationships
 */
trait BlogRelationships
{
    /**
     * Get user of blog.
     * 
     * @return BelongsTo
     */
    public function users(): BelongsTo
    {
        return $this->belongsTo(config('model-variables.models.user.class'));
    }
}
