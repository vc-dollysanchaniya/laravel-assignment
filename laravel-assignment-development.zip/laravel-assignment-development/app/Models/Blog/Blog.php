<?php

namespace App\Models\Blog;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Blog\Traits\Relationships\BlogRelationships;

class Blog extends Model
{
    use HasFactory, BlogRelationships;

    protected $fillable = [
        'blog_title',
        'description',
        'user_id',
        'status'
    ];
}
