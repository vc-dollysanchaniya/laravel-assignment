<?php

namespace App\Models\Blog\Traits\Relationships;

use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Trait UserRelationships
 */
trait UserRelationships
{
    /**
     * Get the all blogs of user.
     * 
     * @return HasMany
     */
    public function blogs(): HasMany
    {
        return $this->hasMany(config('model-variables.models.blog.class'));
    }
}
