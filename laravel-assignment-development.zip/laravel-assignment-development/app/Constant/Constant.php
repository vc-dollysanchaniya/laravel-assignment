<?php

namespace App\Constant;

/**
 * Class Constants
 */
class Constant
{
    /**
     * Boolean value status codes
     */
    public const NULL = null;

    public const STATUS_ZERO = 0;

    public const STATUS_ONE = 1;

    public const STATUS_TWO = 2;

    public const STATUS_TRUE = true;

    public const STATUS_FALSE = false;

    /**
     * String value status codes
     */
    public const ADMIN = 'admin';

    public const USER = 'user';
}
