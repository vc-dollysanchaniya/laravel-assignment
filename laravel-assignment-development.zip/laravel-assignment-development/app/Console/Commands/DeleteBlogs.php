<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Exception;
use App\Constant\Constant;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class DeleteBlogs extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'blogs:delete';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command will delete blogs older than the last 30 days and whose status is Inactive';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        try {
            //Sub days (the $value count passed in) to the instance (using date interval).
            //vendor\nesbot\carbon\src\Carbon\Carbon.php
            DB::beginTransaction();
            config('model-variables.models.blog.class')::where('created_at', '<=', now()->subDays(30))->where('status', Constant::STATUS_ZERO)->delete();
            DB::commit();
            $this->info("success delete");
        } catch (Exception $exception) {
            DB::rollBack();
            Log::error($exception);
            $this->info("error delete");
        }
    }
}
