<?php

namespace App\Http\Controllers\Frontend\Blog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Frontend\Blog\BlogRepository;
use App\Constant\Constant;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use App\Http\Requests\Blog\StoreRequest;

class BlogController extends Controller
{
    /**
     * Blog Repositery.
     *
     * @param BlogRepository
     */
    protected $blogRepository;
    /**
     * @param  BlogRepository  $blogRepository
     */
    public function __construct(BlogRepository $blogRepository)
    {
        $this->blogRepository = $blogRepository;
    }



    /**
     * Display a listing of the resource
     *
     * @return View|RedirectResponse
     */
    public function index(): View|RedirectResponse
    {
        try {
            $blogs = $this->blogRepository->index();
            return view('blogs.list', compact('blogs'));
        } catch (Exception $exception) {
            Log::error($exception);
            return redirect()->back();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return View|RedirectResponse
     */
    public function create(): View
    {
        return view('blogs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreRequest $request)
    {
        try {
            $blogs = $this->blogRepository->store($request->all());
            return redirect()->route('blogs.index');
        } catch (Exception $exception) {
            Log::error($exception);
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return View|RedirectResponse
     */
    public function edit($id): View|RedirectResponse
    {
        try {
            $blog = config('model-variables.models.blog.class')::find($id);
            return view('blogs.edit', compact('blog'));
        } catch (Exception $exception) {
            Log::error($exception);
            return redirect()->back();
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StoreRequest $request, $id)
    {
        try {
            $blogs = $this->blogRepository->update($id, $request->all());
            return redirect()->route('blogs.index');
        } catch (Exception $exception) {
            Log::error($exception);
            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $this->blogRepository->delete($id);
            return redirect()->route('blogs.index');
        } catch (Exception $exception) {
            Log::error($exception);
            return redirect()->back();
        }
    }
}
